-- INSERT INTO user VALUES(1,'test_user_kc','test_password');
-- INSERT INTO user VALUES(2,'simpleusr','password');
-- INSERT INTO user VALUES(3,'user1','234dnjnd+4309!');
-- INSERT INTO user VALUES(4,'user2','330+4!');
-- INSERT INTO user VALUES(5,'user3','boo');
-- INSERT INTO user VALUES(6,'user4','boo1234');

INSERT INTO games VALUES('c911e6b1-b118-4390-bccf-5bdcc74bdae5','Akash','canal',1,0);
INSERT INTO games VALUES('a7b4eb1e-629d-4a1a-861a-31de5af17213','Akash','spoke',1,0);
INSERT INTO games VALUES('311ffcb5-a5ae-4e53-8586-b7f915f373dc','Akash','wrack',1,0);



INSERT INTO guesses VALUES(1,'c911e6b1-b118-4390-bccf-5bdcc74bdae5','brine');
INSERT INTO guesses VALUES(2,'311ffcb5-a5ae-4e53-8586-b7f915f373dc','trash');
INSERT INTO guesses VALUES(3,'311ffcb5-a5ae-4e53-8586-b7f915f373dc','train');
INSERT INTO guesses VALUES(4,'311ffcb5-a5ae-4e53-8586-b7f915f373dc','toxic');
